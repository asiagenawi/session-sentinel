"""claude-powernap: proactive 5-hour-limit survival for Claude Code."""
__version__ = "0.3.0"
